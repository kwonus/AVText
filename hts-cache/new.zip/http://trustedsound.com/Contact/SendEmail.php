<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="generator" content="RapidWeaver" />
		<link rel="icon" href="http://www.AVText.org/favicon.ico" type="image/x-icon" />
		<link rel="shortcut icon" href="http://www.AVText.org/favicon.ico" type="image/x-icon" />
		
		<title>Contact Us | AV Text Ministries</title>
		<link rel="stylesheet" type="text/css" media="screen" href="../rw_common/themes/alpha/styles.css"  />
		<!--[if IE 6]><link rel="stylesheet" type="text/css" media="screen" href="../rw_common/themes/alpha/ie6.css"  /><![endif]-->
		<link rel="stylesheet" type="text/css" media="screen" href="../rw_common/themes/alpha/colourtag.css"  />
		<link rel="stylesheet" type="text/css" media="print" href="../rw_common/themes/alpha/print.css"  />
		<link rel="stylesheet" type="text/css" media="handheld" href="../rw_common/themes/alpha/handheld.css"  />
		<!--[if IE 6]><style type="text/css" media="screen">body {behavior: url(../rw_common/themes/alpha/csshover.htc);}</style><![endif]-->
		<link rel="stylesheet" type="text/css" media="screen" href="../rw_common/themes/alpha/css/width/1000.css" />
		<link rel="stylesheet" type="text/css" media="screen" href="../rw_common/themes/alpha/css/sidebar/sidebar_hide.css" />
				
				
		<script type="text/javascript" src="../rw_common/themes/alpha/javascript.js"></script>
		
		<!--[if IE 6]><script type="text/javascript" charset="utf-8">
			var blankSrc = "../rw_common/themes/alpha/png/blank.gif";
		</script>	
		<style type="text/css">
			img.pngfix {
				behavior:	url("../rw_common/themes/alpha/png/pngbehavior.htc");
			}
		</style><![endif]-->
		
		
	</head>
<body>
<div id="bodyGrad">
	<img class="pngfix" src="../rw_common/themes/alpha/images/body_grad.png" alt="" style="width: 3000px; height: 400px;" />
</div>
<div id="container"><!-- Start container -->
	<div id="pageHeader"><!-- Start page header -->
		<div id="grad"><img class="pngfix" src="../rw_common/themes/alpha/images/header_top_grad.png" alt="" style="width: 3000px; height: 72px;" /></div>
		<img src="../rw_common/images/AV.png" width="90" height="90" alt="Site logo"/>
		<h1>AV Text Ministries</h1>
		<h2>Promoting the Standard that has forever been</h2>
	</div><!-- End page header -->
	<div class="clearer"></div>
	<div id="sidebarContainer"><!-- Start Sidebar wrapper -->
		<div id="sidebar"><!-- Start sidebar content -->
			<h1 class="sideHeader"></h1><!-- Sidebar header -->
			<!-- sidebar content you enter in the page inspector -->
			 <!-- sidebar content such as the blog archive links -->
		</div><!-- End sidebar content -->
	</div><!-- End sidebar wrapper -->
	<div id="contentContainer"><!-- Start main content wrapper -->
		<div id="content"><!-- Start content -->
			
<div class="message-text">Fill in the form below to send me an email.</div><br />

<form class="rw-contact-form" action="./files/mailer.php" method="post" enctype="multipart/form-data">
	 <div>
		<label>Your Name:</label> *<br />
		<input class="form-input-field" type="text" value="" name="form[element0]" size="40"/><br /><br />

		<label>Your Email:</label> *<br />
		<input class="form-input-field" type="text" value="" name="form[element1]" size="40"/><br /><br />

		<label>Subject:</label> *<br />
		<input class="form-input-field" type="text" value="" name="form[element2]" size="40"/><br /><br />

		<label>Message:</label> *<br />
		<textarea class="form-input-field" name="form[element3]" rows="8" cols="38"></textarea><br /><br />

		<div style="display: none;">
			<label>Spam Protection: Please don't fill this in:</label>
			<textarea name="comment" rows="1" cols="1"></textarea>
		</div>
		<input type="hidden" name="form_token" value="975416075640958da1bb32" />
		<input class="form-input-button" type="reset" name="resetButton" value="Reset" />
		<input class="form-input-button" type="submit" name="submitButton" value="Submit" />
	</div>
</form>

<br />
<div class="form-footer"></div><br />

		</div><!-- End content -->
	</div><!-- End main content wrapper -->
	<div class="clearer"></div>
	<div id="footer"><!-- Start Footer -->
		<p>&copy; 1996-2020 Kevin Wonus <a href="/" id="rw_email_contact">return to main page</a></p>
		<div id="breadcrumbcontainer"><!-- Start the breadcrumb wrapper -->
			
		</div><!-- End breadcrumb -->
	</div><!-- End Footer -->
</div><!-- End container -->
</body>
</html>
